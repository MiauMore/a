package Excepciones;

public class EquipoException extends Exception{
    public EquipoException(String str){
        super(str);
    }
}
