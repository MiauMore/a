package Modelo;

public enum EstadoArriendo {
    INICIADO,
    ENTREGADO,
    DEVUELTO
}
