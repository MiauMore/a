package main;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class main {
    public static void main (String[] args){
        List<Curso> cursos = new ArrayList<>();
        cursos.add(new Curso("Cursos profesional de Java", 6.5f, 50, 200 ));
        cursos.add(new Curso("Cursos profesional de Python", 8.5f, 60, 800 ));
        cursos.add(new Curso("Cursos profesional de DB", 4.5f, 70, 700 ));
        cursos.add(new Curso("Cursos profesional de Android", 7.5f, 10, 400 ));
        cursos.add(new Curso("Cursos profesional de Escritura", 1.5f, 10, 300 ));

        long mayorCincoHoras=
                cursos.stream().filter(elemento->elemento.getDuracion()>5).count();

        long menorDosHoras=
                cursos.stream().filter(elemento->elemento.getDuracion()<2).count();

        Stream <Curso> masDeCincuenta=
                cursos.stream().filter(elemento->elemento.getVideos()>50);

        Stream <Curso> tresMayores=
                cursos.stream().sorted(Comparator.comparingDouble());

        System.out.println("Cursos mayores a 5 horas");
        System.out.println(mayorCincoHoras);

        System.out.println("Cursos menores a 2 horas");
        System.out.println(menorDosHoras);

        System.out.println("Cursos con una cantidad de videos mayor a 50");
        masDeCincuenta.forEach(s -> System.out.println(s.getTitulo()));

        System.out.println("Cursos con una cantidad de videos mayor a 50");
        masDeCincuenta.forEach(s -> System.out.println(s.getTitulo()));

        System.out.println("3 cursos con mayor duracion");
        tresMayores.forEach(s -> System.out.println(s.getTitulo()));
    }
}
